export class ComunicadoModel{
    ids?:string;
    titulo:string;
    fecha:string;
    descripcion:string;
    quien:string;
    imagenes?: any;
    archivo?:any;
    
}