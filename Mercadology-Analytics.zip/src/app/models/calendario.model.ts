export class CalendarioModel{
    id?:string;
    title: string;
    start:any;
    myFormData?: any;
}