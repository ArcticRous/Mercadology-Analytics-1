export class ProductividadModel{
    id?:string;
    usuario: string;
    mes:string;
    productividad:number;
}