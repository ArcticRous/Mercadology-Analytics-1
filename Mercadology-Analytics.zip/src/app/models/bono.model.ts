export class BonoModel{
    id?:string;
    BTeam: number;
    BMO: number;
    // desempenio: boolean;
    // objetivos: boolean;
    // sastifaccion: boolean;
}