
export class UsuarioModel{
    nombre: string;
    correo: string;
    password: string;
}

