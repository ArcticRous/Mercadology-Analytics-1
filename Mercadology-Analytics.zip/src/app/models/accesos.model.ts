export class AccesosModel{
    id: string;
    proveedor: string;
    usuario: string;
    contrasena: string;
    observaciones?: string;
}