export class MinutaModel{
    id?: string;
    fecha: Date;
    hora: string;
    numReunion: number;
    asistentes: Object;
    objetivo: string;
    pendientes: Object;
    proxReunion: string;
    elaboro: string;
    autorizo: string;
}